CREATE TABLE USUARIO (

    id int PRIMARY KEY,
    username varchar2(60),
    password varchar2(30)
 
) ;

CREATE TABLE PRODUTO(

    id int PRIMARY KEY,
    nome VARCHAR2(60)NOT NULL,
    preco NUMBER(5,2) NOT NULL,
    quantidade INT 

);

CREATE TABLE VEICULO(

    id int PRIMARY KEY,
    placa varchar2(7) NOT NULL UNIQUE,
    modelo varchar(60) NOT NULL,
    ano int NOT NULL


);


--1 USUARIO tem pedidos
--1 PRODUTO est� em N pedidos, mas 1 PEDIDO tem apenas 1 PRODUTO
--Exemplos para esse cen�rio: 1 VEICULO, 1 CASA, 
CREATE TABLE PEDIDO(

    id int PRIMARY KEY,
    data_pedido date,
    id_usuario int REFERENCES USUARIO(id),
    id_produto int,
    quantidade int,
    valor_total number(5,2),
    CONSTRAINT FK_PRODUTO
      FOREIGN KEY (id_produto)
          REFERENCES PRODUTO(id)

);


CREATE TABLE PEDIDO_VIRTUAL(

    id int PRIMARY KEY,
    data_pedido date,
    id_usuario int REFERENCES USUARIO(id),
    quantidade int,
    valor_total numeric(5,2)

);

--1 PEDIDO TEM N PRODUTOS
--1 PRODUTO ESTA EM N PEDIDO
--PERMITINDO O RELACIONAMENTO M:N
CREATE TABLE PEDIDO_PRODUTO(

    id_pedido int REFERENCES PEDIDO_VIRTUAL (id),
    id_produto int REFERENCES PRODUTO(id),
    quantidade int,
    subtotal numeric(5,2)


);

--APAGAR TABELAS
--DROP TABLE PEDIDO_VIRTUAL;
--DROP TABLE PEDIDO_PRODUTO;  





