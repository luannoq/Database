 CREATE TABLE  MOTORISTA (
    id int PRIMARY KEY,
    nome varchar2 (60),
    cpf varchar2 (11),
    sexo char(1) CHECK (sexo='M' OR sexo='F'),
    status char(1),
    CONSTRAINT CK_STATUS
        CHECK (status='A' OR status='I')
 
 );
 
 --ADICIONAR UM ELEMENTO NA TABELA
 
 ALTER TABLE MOTORISTA
    ADD VEICULO VARCHAR2(60);
    
--REMOVENDO UMA COLUNA NA TABELA(N�o � uma pr�ctica muito usada)
ALTER TABLE VEICULO
    DROP COLUMN modelo;

--ALTERAR TEXTO PARA N�MERO(posso alterar letras maiusculas e minusculas)
ALTER TABLE USUARIO
    MODIFY password VARCHAR2(120);

--RENOMEAR UMA COLUNA
ALTER TABLE USUARIO
    RENAME COLUMN password to senha;

--RENOMEAR UMA TABELA
RENAME VEICULO
    TO CARRO;
    
--REMOVER QUALQUER OBJETO NA TABELA
--DROP TABLE NOME_TABELA
 
 
 