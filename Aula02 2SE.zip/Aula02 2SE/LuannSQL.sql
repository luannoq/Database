CREATE TABLE ALUNO(
    ra int,
    nome varchar (60),
    dt_nascimento date
);    
CREATE TABLE USUARIO(
    id int PRIMARY KEY ,
    username varchar2(60),
    password varchar2(30)
);
    
CREATE TABLE USUARIOV2(
    id int,
    username varchar2(60),
    password varchar2(30),
    CONSTRAINT PK_USUARIO PRIMARY KEY (id)
);    
    
       