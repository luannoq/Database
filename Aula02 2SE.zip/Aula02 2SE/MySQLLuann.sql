-- CREATE DATABASE FIAP;

USE FIAP;
 CREATE TABLE ALUNO(
    ra int,
    nome varchar(60),
    dt_nascimento date
);    
CREATE TABLE USUARIO(
    id int PRIMARY KEY ,
    username varchar(60),
    password varchar(30)
);
    
CREATE TABLE USUARIOV2(
    id int,
    username varchar(60),
    password varchar(30),
    CONSTRAINT PK_USUARIO PRIMARY KEY (id)
);       