INSERT INTO TURMA (nm_turma, st_turma)
VALUES ('1TDSPA', 'A');

INSERT INTO TURMA (nm_turma,st_turma)
VALUES ('1TDSPB', 'A');

INSERT INTO ALUNO (id, nm_aluno, sx_aluno)
VALUES (1,'Beatriz', 'f');

INSERT INTO ALUNO (id, nm_aluno, sx_aluno)
VALUES (2,'Matheus', 'm');

INSERT INTO DISCIPLINA (nm_disciplina)
VALUES ('Building Relacional Database');

INSERT INTO DISCIPLINA (nm_disciplina)
VALUES ('Domain Driven Design');

INSERT INTO GRADE_DISCIPLINA (id_turma, id_disciplina)
VALUES (1,1);

INSERT INTO GRADE_DISCIPLINA (id_turma, id_disciplina)
VALUES (1,2);



--CONSULTA SIMPLES: RETORNA TODAS AS LINHAS E COLUNAS
SELECT * FROM TURMA;
SELECT * FROM ALUNO;
SELECT * FROM DISCIPLINA;
SELECT* FROM GRADE_DISCIPLINA;


--UPDATE: ATUALIZANDO DADOS
--update gen�rico: ir� atualizar todas as linhas
UPDATE ALUNO SET id_turma= 1;

--update expec�fico: atualizar cpf do aluno
UPDATE ALUNO SET cpf_aluno='12345678910' WHERE id=1;

--CONSTRAINTS: TESTES



--CONSTRAINTS: TESTE

