DROP TABLE PRODUTO CASCADE CONSTRAINTS;
--removendo todas as refer�ncias em FK

CREATE TABLE "PRODUTO"(
    "ID_PRODUTO" INTEGER PRIMARY KEY,
    "DESC_PRODUTO" VARCHAR2(100),
    "VALOR_PRODUTO" NUMBER
)

-- Inserindo dados na tabela "PRODUTO"
INSERT INTO "PRODUTO" ("ID_PRODUTO", "DESC_PRODUTO", "VALOR_PRODUTO") VALUES (1, 'Produto A', 10.99);
INSERT INTO "PRODUTO" ("ID_PRODUTO", "DESC_PRODUTO", "VALOR_PRODUTO") VALUES (2, 'Produto B', 25.49);
INSERT INTO "PRODUTO" ("ID_PRODUTO", "DESC_PRODUTO", "VALOR_PRODUTO") VALUES (3, 'Produto C', 5.75);
INSERT INTO "PRODUTO" ("ID_PRODUTO", "DESC_PRODUTO", "VALOR_PRODUTO") VALUES (4, 'Produto D', 15.99);
INSERT INTO "PRODUTO" ("ID_PRODUTO", "DESC_PRODUTO", "VALOR_PRODUTO") VALUES (5, 'Produto E', 8.25);
INSERT INTO "PRODUTO" ("ID_PRODUTO", "DESC_PRODUTO", "VALOR_PRODUTO") VALUES (6, 'Produto F', 19.99);
INSERT INTO "PRODUTO" ("ID_PRODUTO", "DESC_PRODUTO", "VALOR_PRODUTO") VALUES (7, 'Produto G', 12.50);
INSERT INTO "PRODUTO" ("ID_PRODUTO", "DESC_PRODUTO", "VALOR_PRODUTO") VALUES (8, 'Produto H', 7.75);
INSERT INTO "PRODUTO" ("ID_PRODUTO", "DESC_PRODUTO", "VALOR_PRODUTO") VALUES (9, 'Produto I', 14.99);
INSERT INTO "PRODUTO" ("ID_PRODUTO", "DESC_PRODUTO", "VALOR_PRODUTO") VALUES (10, 'Produto J', 9.99);
INSERT INTO "PRODUTO" ("ID_PRODUTO", "DESC_PRODUTO", "VALOR_PRODUTO") VALUES (11, 'Produto K', 12.25);
INSERT INTO "PRODUTO" ("ID_PRODUTO", "DESC_PRODUTO", "VALOR_PRODUTO") VALUES (12, 'Produto L', 6.50);
INSERT INTO "PRODUTO" ("ID_PRODUTO", "DESC_PRODUTO", "VALOR_PRODUTO") VALUES (13, 'Produto M', 17.75);
INSERT INTO "PRODUTO" ("ID_PRODUTO", "DESC_PRODUTO", "VALOR_PRODUTO") VALUES (14, 'Produto N', 22.99);
INSERT INTO "PRODUTO" ("ID_PRODUTO", "DESC_PRODUTO", "VALOR_PRODUTO") VALUES (15, 'Produto O', 14.50);
INSERT INTO "PRODUTO" ("ID_PRODUTO", "DESC_PRODUTO", "VALOR_PRODUTO") VALUES (16, 'Produto P', 8.75);
INSERT INTO "PRODUTO" ("ID_PRODUTO", "DESC_PRODUTO", "VALOR_PRODUTO") VALUES (17, 'Produto Q', 11.99);
INSERT INTO "PRODUTO" ("ID_PRODUTO", "DESC_PRODUTO", "VALOR_PRODUTO") VALUES (18, 'Produto R', 19.25);
INSERT INTO "PRODUTO" ("ID_PRODUTO", "DESC_PRODUTO", "VALOR_PRODUTO") VALUES (19, 'Produto S', 5.99);
INSERT INTO "PRODUTO" ("ID_PRODUTO", "DESC_PRODUTO", "VALOR_PRODUTO") VALUES (20, 'Produto T', 10.00);

SELECT * FROM "PRODUTO";
--Consulta simples
-- *: todas as colunas
--FROM: qual a tabela

--Consulta Procedural (ou especifica, filtradas)

SELECT desc_produto, valor_produto FROM PRODUTO;
--Selecionando quais as colunas ser�o exibidas em todas as linhas

SELECT desc_produto, valor_produto
FROM PRODUTO
WHERE id_produto=1;
--selecionando quais colunas ser�o exibidas para N linhas
--WHERE � a minha condi��o de filtragem de dados

--Operadores de compara��o

SELECT * FROM PRODUTO
WHERE valor_produto>10;

SELECT *FROM PRODUTO
WHERE valor_produto < 10;

--Operadores L�gicos
--AND

SELECT * FROM PRODUTO
WHERE valor_produto >10 AND valor_produto<15;
--Foi se realizado um Intervalo de Valores

--OR

SELECT * FROM PRODUTO
WHERE desc_produto = 'Produto A'
        OR desc_produto='Produto B' OR desc_produto='Produto';
--Foi se realizar uma Lista de Valores

--BETWEEN

SELECT * FROM PRODUTO 
WHERE valor_produto BETWEEN 10 AND 15;
--Foi se realizado um Intervalo de Valor, simplifica��o do AND

--IN 
SELECT *FROM PRODUTO
WHERE desc_produto IN ('Produto A', 'Produto B', 'Produto');

--LIKE
SELECT * FROM PRODUTO
WHERE desc_produto LIKE 'Produto A;
--Mesma coisa que o operador de desigual

--LIKE COM %
SELECT * FROM PRODUTO
WHERE desc_produto LIKE 'P%';
--Traga tudo que tenha caracter P no inicio

SELECT * FROM PRODUTO 
WHERE desc_produto LIKE '%P'
--Traga tudo que tenha caracter P no final

SELECT * FROM PRODUTO
WHERE desc_produto LIKE '%to%'
--Traga tudo q teenha to

--NOT LIKE
SELECT * FROM PRODUTO
WHERE desc_produto NOT LIKE 'Produto A';

--SELECT com Functions
SELECT
    valor_produto,
    ROUND (valor_produto,2) vl_produto_round,
    MOD (valor_produto,2)vl_produto_mod,
    TRUNC (valor_produto,0)vl_produto_trunc,--ALIAS: modificando o nome da coluna
    valor_produto *(-1),
    ABS (valor_produto*(-1)), --tirar numeros negativos e positivos
    CEIL (valor_produto),
    FLOOR (valor_produto),  
    SQRT (valor_produto)
FROM PRODUTO;














